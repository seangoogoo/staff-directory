-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : mar. 25 mars 2025 à 19:49
-- Version du serveur : 11.7.2-MariaDB
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `staff_dir`
--
CREATE DATABASE IF NOT EXISTS `staff_dir` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `staff_dir`;

-- --------------------------------------------------------

--
-- Structure de la table `app_settings`
--

CREATE TABLE `app_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Déchargement des données de la table `app_settings`
--

INSERT INTO `app_settings` (`id`, `setting_key`, `setting_value`, `created_at`, `updated_at`) VALUES
(1, 'font_weight', 'Regular', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(2, 'font_size_factor', '3', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(3, 'custom_logo_path', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(4, 'frontend_title', 'My company', '2025-03-23 17:43:02', '2025-03-23 21:57:31'),
(5, 'admin_title', 'Staff Directory Admin', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(6, 'show_logo', '1', '2025-03-23 17:43:02', '2025-03-23 17:43:02');

-- --------------------------------------------------------

--
-- Structure de la table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `color` varchar(7) DEFAULT '#6c757d',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Déchargement des données de la table `departments`
--

INSERT INTO `departments` (`id`, `name`, `description`, `color`, `created_at`, `updated_at`) VALUES
(1, 'Product Management', 'Defines product vision, roadmaps, and requirements', '#94C2F3', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(2, 'Frontend Development', 'Develops user interfaces and client-side logic', '#A8D8AD', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(3, 'Backend Development', 'Builds server-side logic, APIs, and databases', '#F4B8B8', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(4, 'Mobile Development', 'Creates applications for mobile platforms (iOS, Android)', '#FFEAAA', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(5, 'Quality Assurance (QA)', 'Tests software to ensure quality and functionality', '#9FE0E0', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(6, 'DevOps', 'Manages infrastructure, deployment, and automation', '#B19CD9', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(7, 'UI/UX Design', 'Designs user interfaces and user experiences', '#F8C471', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(8, 'Cybersecurity', 'Protects systems and data from security threats', '#EC7063', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(9, 'Data Analysis', 'Analyzes data to provide insights and improve products', '#5DADE2', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(10, 'Technical Support', 'Provides technical assistance to users', '#45B39D', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(11, 'Project Management', 'Plans, executes, and monitors software development projects', '#D7BDE2', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(12, 'General IT/Systems', 'Manages internal company computer systems, and network', '#7DCEA0', '2025-03-23 17:43:02', '2025-03-23 17:43:02');

-- --------------------------------------------------------

--
-- Structure de la table `staff_members`
--

CREATE TABLE `staff_members` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  `job_title` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `profile_picture` varchar(255) DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

--
-- Déchargement des données de la table `staff_members`
--

INSERT INTO `staff_members` (`id`, `first_name`, `last_name`, `department_id`, `job_title`, `email`, `profile_picture`, `created_at`, `updated_at`) VALUES
(1, 'Antoine', 'Dupont', 2, 'Frontend Developer', 'antoine.dupont@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(2, 'Sophia', 'Müller', 3, 'Backend Developer', 'sophia.muller@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(3, 'Marco', 'Rossi', 4, 'Mobile Developer (iOS)', 'marco.rossi@staffdirectory.com', '67e04cd753f92.webp', '2025-03-23 17:43:02', '2025-03-23 18:03:03'),
(4, 'Amélie', 'Laurent', 5, 'QA Tester', 'amelie.laurent@staffdirectory.com', '67e04c375208b.webp', '2025-03-23 17:43:02', '2025-03-23 18:00:23'),
(5, 'Lukas', 'Schmidt', 6, 'DevOps Engineer', 'lukas.schmidt@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(6, 'Isabella', 'Bianchi', 7, 'UX Designer', 'isabella.bianchi@staffdirectory.com', '67e06a48163fb.webp', '2025-03-23 17:43:02', '2025-03-23 20:08:40'),
(7, 'Henrik', 'Andersson', 8, 'Security Analyst', 'henrik.andersson@staffdirectory.com', '67e06a33be855.webp', '2025-03-23 17:43:02', '2025-03-23 20:08:19'),
(8, 'Elena', 'Petrov', 9, 'Data Analyst', 'elena.petrov@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(9, 'Pierre', 'Moreau', 10, 'Technical Support Specialist', 'pierre.moreau@staffdirectory.com', '67e04d0e6a627.webp', '2025-03-23 17:43:02', '2025-03-23 18:03:58'),
(10, 'Ingrid', 'Nielsen', 11, 'Project Manager', 'ingrid.nielsen@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(11, 'Sven', 'Eriksson', 12, 'IT Support', 'sven.eriksson@staffdirectory.com', '67e04d3ab4ec5.webp', '2025-03-23 17:43:02', '2025-03-23 18:04:42'),
(12, 'Clara', 'Fischer', 1, 'Business Analyst', 'clara.fischer@staffdirectory.com', '67e04c5e081ac.webp', '2025-03-23 17:43:02', '2025-03-23 18:01:02'),
(13, 'Matteo', 'Conti', 2, 'UI Developer', 'matteo.conti@staffdirectory.com', '67e04cfc20a2f.webp', '2025-03-23 17:43:02', '2025-03-23 18:03:40'),
(14, 'Camille', 'Bernard', 3, 'API Developer', 'camille.bernard@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(15, 'Andreas', 'Weber', 4, 'Mobile Developer (Android)', 'andreas.weber@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(16, 'Sophie', 'Dubois', 5, 'QA Analyst', 'sophie.dubois@staffdirectory.com', '67e04d1f1f9e3.webp', '2025-03-23 17:43:02', '2025-03-23 18:04:15'),
(17, 'Viktor', 'Kowalski', 6, 'Systems Administrator', 'viktor.kowalski@staffdirectory.com', '67e04d5641b3f.webp', '2025-03-23 17:43:02', '2025-03-23 18:05:10'),
(18, 'Alessandra', 'Ferrari', 7, 'UI Designer', 'alessandra.ferrari@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(19, 'Nikolai', 'Ivanov', 8, 'Security Engineer', 'nikolai.ivanov@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(20, 'Elisa', 'Santos', 9, 'Data Engineer', 'elisa.santos@staffdirectory.com', '67e04c779f6e4.webp', '2025-03-23 17:43:02', '2025-03-23 18:01:27'),
(21, 'François', 'Martin', 10, 'Customer Support Engineer', 'francois.martin@staffdirectory.com', '67e04c8ba6606.webp', '2025-03-23 17:43:02', '2025-03-23 18:01:47'),
(22, 'Linnea', 'Lindholm', 11, 'Scrum Master', 'linnea.lindholm@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02'),
(23, 'Jens', 'Hoffmann', 12, 'Network Administrator', 'jens.hoffmann@staffdirectory.com', '', '2025-03-23 17:43:02', '2025-03-23 17:43:02');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Index pour la table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `staff_members`
--
ALTER TABLE `staff_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `app_settings`
--
ALTER TABLE `app_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `staff_members`
--
ALTER TABLE `staff_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `staff_members`
--
ALTER TABLE `staff_members`
  ADD CONSTRAINT `staff_members_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
